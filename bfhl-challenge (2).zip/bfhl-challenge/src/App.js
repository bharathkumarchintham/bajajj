import React, { useState } from "react";
import axios from "axios";

function App() {
  const [input, setInput] = useState("");
  const [response, setResponse] = useState({});
  const [selectedOptions, setSelectedOptions] = useState([]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const jsonInput = JSON.parse(input);
      const res = await axios.post(
        "https://your-backend-api.com/bfhl",
        jsonInput
      );
      setResponse(res.data);
    } catch (error) {
      console.error("Error:", error);
      alert("Invalid JSON input or API call failed.");
    }
  };

  const handleSelectChange = (event) => {
    const selectedOptions = event.target.selectedOptions;
    const selectedValues = Array.from(
      selectedOptions,
      (option) => option.value
    );
    setSelectedOptions(selectedValues);
  };

  const filteredResponse = () => {
    const filteredData = {};
    selectedOptions.forEach((option) => {
      if (option === "Alphabets") {
        filteredData.alphabets = response.alphabets;
      } else if (option === "Numbers") {
        filteredData.numbers = response.numbers;
      } else if (option === "Highest Alphabet") {
        filteredData.highest_alphabet = response.highest_alphabet;
      }
    });
    return filteredData;
  };

  const renderFilteredResponse = () => {
    const data = filteredResponse();
    return (
      <div>
        {Object.keys(data).map((key) => (
          <div key={key}>
            <h3>{key}:</h3>
            <p>{Array.isArray(data[key]) ? data[key].join(", ") : data[key]}</p>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div>
      <h1>BFHL Challenge</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={input}
          onChange={(event) => setInput(event.target.value)}
          placeholder="Enter JSON input"
        />
        <button type="submit">Submit</button>
      </form>
      {response && (
        <div>
          <select multiple onChange={handleSelectChange}>
            <option value="Alphabets">Alphabets</option>
            <option value="Numbers">Numbers</option>
            <option value="Highest Alphabet">Highest Alphabet</option>
          </select>
          <div>{renderFilteredResponse()}</div>
        </div>
      )}
    </div>
  );
}

export default App;

